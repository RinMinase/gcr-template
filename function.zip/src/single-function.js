module.exports = function test(params) {
    return "value";
}